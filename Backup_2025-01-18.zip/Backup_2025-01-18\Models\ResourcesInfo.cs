namespace EBDC.Models
{
    public class ResourcesInfo
    {
        public double MemoryUsageMB { get; set; }
    }
}
